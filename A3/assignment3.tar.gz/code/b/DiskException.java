public class DiskException extends Exception {

	public DiskException(String message){
		super(message);
	}
}