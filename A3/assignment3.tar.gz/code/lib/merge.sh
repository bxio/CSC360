#
# Please use the makefile instead
#
jar -uf ClassLinker.jar ClassLinker.control
