/*
** simpleRTJ java language core library component.
**
** See the http://www.gnu.org/copyleft/gpl.html for
** details on usage and redistribution of this file.
*/

package java.io;

public abstract interface FilenameFilter
{
    public abstract boolean accept(File dir, String name);
}

