var searchData=
[
  ['read',['read',['../classuvic_1_1disk_1_1_disk_scheduler.html#a56029ea24cbdba4efd4e5b1dafec7316',1,'uvic::disk::DiskScheduler']]],
  ['read_5ffile',['read_file',['../class_file_system.html#a057e83d5edf52e452f4bd1406745d15f',1,'FileSystem']]],
  ['readln',['readln',['../classjava_1_1lang_1_1_system.html#abfcf7318f917f797abe2b5ce83cd8b6c',1,'java::lang::System']]],
  ['real_5ftime',['REAL_TIME',['../classuvic_1_1posix_1_1_thread.html#a0f5ee3074cca92d2223e35755b365617',1,'uvic::posix::Thread']]],
  ['regionmatches',['regionMatches',['../classjava_1_1lang_1_1_string.html#aa5970db44826bbd7bd1c0a3fd930272b',1,'java.lang.String.regionMatches(int toffset, String other, int ooffset, int len)'],['../classjava_1_1lang_1_1_string.html#a8e2ab15a781cf355f062248417f28d80',1,'java.lang.String.regionMatches(boolean ignoreCase, int toffset, String other, int ooffset, int len)']]],
  ['remove',['remove',['../class_disk_c_s_c_a_n.html#ad766b2fbae9895cd9508ef0dad00b275',1,'DiskCSCAN.remove()'],['../class_disk_c_s_c_a_n.html#ad766b2fbae9895cd9508ef0dad00b275',1,'DiskCSCAN.remove()'],['../class_disk_f_c_f_s.html#ab88d0a34332eaabe3e0e292ff1d8ff48',1,'DiskFCFS.remove()'],['../class_disk_s_s_t_f.html#ad317c462a306272617c4320abecabbd3',1,'DiskSSTF.remove()'],['../class_disk_f_c_f_s.html#ab88d0a34332eaabe3e0e292ff1d8ff48',1,'DiskFCFS.remove()'],['../classuvic_1_1disk_1_1_disk_scheduler.html#affc90f4cd5a9bea6b48fda65cee4a3be',1,'uvic.disk.DiskScheduler.remove()']]],
  ['run',['run',['../class_disk_requester.html#a9dd1f0bb10491bd1039c6982062b9090',1,'DiskRequester.run()'],['../class_file_system.html#a4b330745d86dc5a73178cc8f2d2b306a',1,'FileSystem.run()'],['../interfacejava_1_1lang_1_1_runnable.html#af50ec7c766d4e92b48d73989aa651d10',1,'java.lang.Runnable.run()'],['../classjava_1_1lang_1_1_thread.html#a444265c3a24133bfeb25743435cf89f2',1,'java.lang.Thread.run()'],['../classuvic_1_1disk_1_1_disk_scheduler.html#a4935c469cb2e1f001a2f9a0ef66b96bc',1,'uvic.disk.DiskScheduler.run()'],['../classuvic_1_1posix_1_1_thread.html#ac3f3f8eddc0492f6a59264d6ffd216d5',1,'uvic.posix.Thread.run()']]],
  ['runnable',['Runnable',['../interfacejava_1_1lang_1_1_runnable.html',1,'java::lang']]],
  ['runtimeexception',['RuntimeException',['../classjava_1_1lang_1_1_runtime_exception.html',1,'java::lang']]]
];
