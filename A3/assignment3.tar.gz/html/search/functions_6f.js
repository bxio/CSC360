var searchData=
[
  ['outofmemoryerror',['OutOfMemoryError',['../classjava_1_1lang_1_1_out_of_memory_error.html#a2dee30cd5a9cbe4e80cd0067d16f09d7',1,'java.lang.OutOfMemoryError.OutOfMemoryError()'],['../classjava_1_1lang_1_1_out_of_memory_error.html#acfc9f986f0ec84e9d7a66f5a6e768945',1,'java.lang.OutOfMemoryError.OutOfMemoryError(String s)']]]
];
