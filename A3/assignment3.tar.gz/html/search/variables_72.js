var searchData=
[
  ['real_5ftime',['REAL_TIME',['../classuvic_1_1posix_1_1_thread.html#a0f5ee3074cca92d2223e35755b365617',1,'uvic::posix::Thread']]]
];
