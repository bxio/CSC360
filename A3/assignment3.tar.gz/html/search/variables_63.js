var searchData=
[
  ['current',['current',['../classuvic_1_1disk_1_1_disk_scheduler.html#a31e6fb38e4fb703e9121560ce358c013',1,'uvic::disk::DiskScheduler']]]
];
