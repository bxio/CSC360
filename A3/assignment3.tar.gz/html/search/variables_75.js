var searchData=
[
  ['user',['USER',['../classuvic_1_1posix_1_1_thread.html#aacca58bc743f364a3c4670ee9e207472',1,'uvic::posix::Thread']]]
];
