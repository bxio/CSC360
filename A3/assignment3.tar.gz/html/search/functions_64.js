var searchData=
[
  ['delete_5ffile',['delete_file',['../class_file_system.html#a6093d9b668b96679706bc4c154deb4b5',1,'FileSystem']]],
  ['deq',['deQ',['../classuvic_1_1disk_1_1_disk_request.html#a10801692e7b7872c5f3cb006543b5487',1,'uvic::disk::DiskRequest']]],
  ['diskcscan',['DiskCSCAN',['../class_disk_c_s_c_a_n.html#a3439652deec2c5a25e578f06522367ce',1,'DiskCSCAN.DiskCSCAN(int startPosition)'],['../class_disk_c_s_c_a_n.html#a3439652deec2c5a25e578f06522367ce',1,'DiskCSCAN.DiskCSCAN(int startPosition)']]],
  ['diskfcfs',['DiskFCFS',['../class_disk_f_c_f_s.html#abc6284df9e7388ffeaff6575bf0b2d62',1,'DiskFCFS.DiskFCFS(int startPosition)'],['../class_disk_f_c_f_s.html#abc6284df9e7388ffeaff6575bf0b2d62',1,'DiskFCFS.DiskFCFS(int startPosition)']]],
  ['diskrequester',['DiskRequester',['../class_disk_requester.html#a0e897b805479dbf8235058628fd7a0a3',1,'DiskRequester']]],
  ['diskscheduler',['DiskScheduler',['../classuvic_1_1disk_1_1_disk_scheduler.html#a7c7dc545469cc507f30d0f8e05e0b7aa',1,'uvic::disk::DiskScheduler']]],
  ['disksstf',['DiskSSTF',['../class_disk_s_s_t_f.html#ac2527a3221ca5077b26df841536ad8b7',1,'DiskSSTF']]]
];
