var searchData=
[
  ['system',['SYSTEM',['../classuvic_1_1posix_1_1_thread.html#af91f254a048b7b6ceca4b9749e1b1352',1,'uvic::posix::Thread']]]
];
