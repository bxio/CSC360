var searchData=
[
  ['daemon',['DAEMON',['../classuvic_1_1posix_1_1_thread.html#abfa63734bd921d729b461d82f532f1e3',1,'uvic::posix::Thread']]]
];
